package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class HomePage extends PageParameters{
	
	// 1. lokatoriai
	
	By linkCreateNewAccount =By.xpath("/html/body/div/form/div/h4/a");
	By inputUsername =By.xpath("/html/body/div/form/div/input[1]");
	By inputPassword =By.xpath("/html/body/div/form/div/input[2]");
	By buttonLogIn = By.xpath("/html/body/div/form/div/button");
	
	
		
	// 2. konstruktorius
		
	public HomePage(WebDriver driver) {
			this.driver=driver;
		}
	// 3. metodai
		
	public void PressLinkCreateNewAccount() {
			driver.findElement(linkCreateNewAccount).click();
	}
	
	public void EnterPersonalData (String username, String password) {
		driver.findElement(inputUsername).sendKeys(username);
		driver.findElement(inputPassword).sendKeys(password);
	}
	
	public void ClearPersonalData () {
		driver.findElement(inputUsername).clear();
		driver.findElement(inputPassword).clear();
	}
	
	public void SubmitApplication () {
		driver.findElement(buttonLogIn).click();
	}
}
	
		
		