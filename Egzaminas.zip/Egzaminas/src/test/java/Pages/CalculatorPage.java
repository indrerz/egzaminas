package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class CalculatorPage extends PageParameters {
	
	// 1. lokatoriai
	
		By buttonLogout =By.xpath("/html/body/nav/div/ul[2]/a");
	
		
		
			
		// 2. konstruktorius
			
		public CalculatorPage(WebDriver driver) {
				this.driver=driver;
			}
		// 3. metodai
			
		public void PressButtonToLogout() {
				driver.findElement(buttonLogout).click();
		}
}
		

		
			
			