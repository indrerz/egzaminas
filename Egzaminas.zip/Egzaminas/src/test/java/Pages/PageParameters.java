package Pages;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class PageParameters {
	protected WebDriver driver;
	
	public void PageParameters(WebDriver driver) { //turi sutapti su public class pavadinimu
	this.driver =driver;
	PageFactory.initElements(driver,this);

  }
}
