package Pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class SignUpPage extends PageParameters{
	
	// 1. lokatoriai
	
	By inputUsername =By.xpath("//*[@id=\"username\"]");
	By inputPassword =By.xpath("//*[@id=\"password\"]");
	By inputPasswordConfirm =By.xpath("//*[@id=\"passwordConfirm\"]");
	By buttonCreate =By.xpath("/html/body/div/form/button");
	
		
			
	// 2. konstruktorius
			
	public SignUpPage(WebDriver driver) {
				this.driver=driver;
			}
	// 3. metodai
			
	public void EnterPersonalData (String username, String password, String password1) {
		driver.findElement(inputUsername).sendKeys(username);
		driver.findElement(inputPassword).sendKeys(password);
		driver.findElement(inputPasswordConfirm).sendKeys(password1);
	}
	
	public void ClearPersonalData () {
		driver.findElement(inputUsername).clear();
		driver.findElement(inputPassword).clear();
		driver.findElement(inputPasswordConfirm).clear();
	}
	
	public void SubmitApplication () {
		driver.findElement(buttonCreate).click();
	}
	}
