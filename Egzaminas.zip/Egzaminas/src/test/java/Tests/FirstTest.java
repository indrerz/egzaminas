package Tests;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import Pages.HomePage;
import Pages.SignUpPage;

public class FirstTest extends TestsParameters {
  @Test
  public void RegisterNewAccountAllMandatoryFields() throws Exception, InterruptedException {
	  	HomePage hp = new HomePage(driver);
	  	SignUpPage sp = new SignUpPage(driver);
	  	hp.PressLinkCreateNewAccount();
	  	Thread.sleep(2000);
	  	ArrayList<String> SignUp = getTestDataArray("src/test/resources/SignUpData.txt");
	  	int a = SignUp.size();  //kintmasis filo pavadinismas, kuriame suvesti duomenys
	  	for(int i=0;i<a; i++) {//i-eilut�s skai�ius nuo kurio pradeda imti duomenis (0pagal programavim� lygu 1),i++ kiekvien� kart� �ra�tant ima vis kit� pagal eil�, bet ne daugiau nei a (�vesta reik�mi�)
		String [] value = SignUp.get(i).split(",",3);
		sp.ClearPersonalData();
		sp.EnterPersonalData(value[0],value[1],value[2]);
		sp.SubmitApplication();
		Thread.sleep(3000);
		takeSnapShot(driver);
		Thread.sleep(1000);
		resultsToFile("The end of test", "src/test/resources/Results.txt");
  }
  }

  		@Test
  		public void DoNotFillMandatoryFields () throws Exception {
  		HomePage hp = new HomePage(driver);
  		SignUpPage sp = new SignUpPage(driver);
  		hp.PressLinkCreateNewAccount();
  		Thread.sleep(2000);
  		ArrayList<String> SignUp = getTestDataArray("src/test/resources/SignUpAllFieldsEmpty.txt");
  		int a = SignUp.size();  //kintmasis filo pavadinismas, kuriame suvesti duomenys
  		for(int i=0;i<a; i++) {//i-eilut�s skai�ius nuo kurio pradeda imti duomenis (0pagal programavim� lygu 1),i++ kiekvien� kart� �ra�tant ima vis kit� pagal eil�, bet ne daugiau nei a (�vesta reik�mi�)
  		String [] value = SignUp.get(i).split(",",3);
  		sp.ClearPersonalData();
  		sp.EnterPersonalData(value[0],value[1],value[2]);
  		sp.SubmitApplication();
  		Thread.sleep(3000);
  		takeSnapShot(driver);
  		Thread.sleep(1000);
  		resultsToFile("The end of test", "src/test/resources/Results.txt");
}
  }
  		
  		
  		@Test
  		public void EnterExistingData () throws Exception {
  		HomePage hp = new HomePage(driver);
  		SignUpPage sp = new SignUpPage(driver);
  		hp.PressLinkCreateNewAccount();
  		Thread.sleep(2000);
  		ArrayList<String> SignUp = getTestDataArray("src/test/resources/ExistingData.txt");
  		int a = SignUp.size();  //kintmasis filo pavadinismas, kuriame suvesti duomenys
  		for(int i=0;i<a; i++) {//i-eilut�s skai�ius nuo kurio pradeda imti duomenis (0pagal programavim� lygu 1),i++ kiekvien� kart� �ra�tant ima vis kit� pagal eil�, bet ne daugiau nei a (�vesta reik�mi�)
  		String [] value = SignUp.get(i).split(",",3);
  		sp.ClearPersonalData();
  		sp.EnterPersonalData(value[0],value[1],value[2]);
  		sp.SubmitApplication();
  		Thread.sleep(3000);
  		String message = driver.findElement(By.xpath("//*[@id=\"username.errors\"]")).getText();
		Thread.sleep(1000);
		assertEquals("Toks vartotojo vardas jau egzistuoja", message); //tikriname ar gautas prane�imas atitinka laukiam�
		Thread.sleep(1000);
		resultsToFile("Message: "+message, "src/test/resources/Results.txt");
  		takeSnapShot(driver);
  		Thread.sleep(2000);

} 
  } 	
    }
