package Tests;

import java.util.ArrayList;

import org.testng.annotations.Test;

import Pages.CalculatorPage;
import Pages.HomePage;

public class ThirdTest extends TestsParameters {
	
	@Test
	public void LogOut () throws Exception {
	HomePage hp = new HomePage(driver);
	CalculatorPage cp = new CalculatorPage(driver);
	ArrayList<String> LogIn = getTestDataArray("src/test/resources/LogInData.txt");
    int a = LogIn.size();  //kintmasis filo pavadinismas, kuriame suvesti duomenys
	for(int i=0;i<a; i++) {//i-eilut�s skai�ius nuo kurio pradeda imti duomenis (0pagal programavim� lygu 1),i++ kiekvien� kart� �ra�tant ima vis kit� pagal eil�, bet ne daugiau nei a (�vesta reik�mi�)
	String [] value = LogIn.get(i).split(",",2);
	hp.ClearPersonalData();
	hp.EnterPersonalData(value[0],value[1]);
	hp.SubmitApplication();
	Thread.sleep(2000);
	cp.PressButtonToLogout();
	resultsToFile("The end of test", "src/test/resources/Results.txt");
	takeSnapShot(driver);
	}
	}
}